from typing import Callable

import requests
from authentication import get_auth_header


def get_paginated_new_releases(
    base_url: str, access_token: str, get_token: Callable, **kwargs
) -> list:
    """Performs paginated calls to the new releases endpoint. Manages token refresh when required.

    Args:
        base_url (str): Base URL for API requests
        access_token (str): Access token
        get_token (Callable): Function that requests access token

    Returns:
        list: Request responses stored as a list
    """
    headers = get_auth_header(access_token=access_token)
    request_url = base_url
    new_releases_data = []

    try:
        while request_url:
            print(f"Requesting to: {request_url}")
            response = requests.get(url=request_url, headers=headers)

            ### Exercise 4:
            ### START CODE HERE ### (~ 11 lines of code)
            # Create an if condition over the status code of the response
            if response.status_code == 401:  # Unauthorized
                # Handle token expiration and update
                token_response = get_token()  # Call the get_token function to refresh the token
                if token_response:  # Check if token refresh was successful
                    access_token = token_response.get('access_token')  # Get new access token
                    headers = get_auth_header(access_token=access_token)  # Update headers with the new token
                    print("Token has been refreshed")
                    continue  # Retry the request with the updated token
                else:
                    print("Failed to refresh token.")
                    return []  # Return an empty list if token refresh fails
            ### END CODE HERE ###
            

            response_json = response.json()
            new_releases_data.extend(response_json["albums"]["items"])
            request_url = response_json["albums"]["next"]

        return new_releases_data

    except Exception as err:
        print(f"Error occurred during request: {err}")
        return []

from typing import Callable
import requests
from authentication import get_auth_header

def get_paginated_album_tracks(
    base_url: str,
    access_token: str,
    album_id: str,
    get_token: Callable,
    **kwargs,
) -> list:
    """Performs paginated requests to the album/{album_id}/tracks endpoint

    Args:
        base_url (str): Base URL for endpoint requests
        access_token (str): Access token
        album_id (str): Id of the album to be queried
        get_token (Callable): Function that requests access token

    Returns:
        list: Request responses stored as a list
    """
    # Call the get_auth_header() function with the access token.
    headers = get_auth_header(access_token=access_token)
    # Create the request URL by using the base_url and album_id parameters.
    request_url = f"{base_url}/{album_id}/tracks"
    album_data = []

    try:
        while request_url:
            print(f"Requesting to: {request_url}")
            # Perform a GET request using the request_url and headers.
            response = requests.get(url=request_url, headers=headers)
            print(f"Response: {response}")

            if response.status_code == 401:  # Unauthorized
                # Handle token expiration and update.
                token_response = get_token()  # Call the get_token function to refresh the token
                if token_response:  # Check if token refresh was successful
                    # Call get_auth_header() function with the new access token from token_response.
                    access_token = token_response.get('access_token')
                    headers = get_auth_header(access_token=access_token)  # Update headers
                    print("Token has been refreshed")
                    continue  # Retry the request with the updated token
                else:
                    print("Failed to refresh token.")
                    return []

            # Convert the response to json using the json() method.
            response_json = response.json()
            # Extend the album_data list with the value from "items" in response_json.
            album_data.extend(response_json.get("items", []))
            # Update request_url with the "next" value from response_json.
            request_url = response_json.get("next")  # Safely get the next page URL

        return album_data

    except Exception as err:
        print(f"Error occurred during request: {err}")
        return []
